package com.kotlindemo

sealed class Hello(val name: String) {

    init {
        println("Initializing Hello")
    }

    open val size: Int =
            name.length.also { println("Initializing size in Hello: $it") }
}

class Derived(name: String, val lastName: String) : Hello(name.capitalize().also { println("Argument for Hello: $it") }) {

    init {
        println("Initializing Derived")
    }

    override val size: Int =
            (super.size + lastName.length).also { println("Initializing size in Derived: $it") }
}

fun main() {
    println("Constructing Derived(\"hello\", \"world\")")
    val d = Derived("hello", "world")
}

/////////////////////////////////////////////////////////////////////////////////////////////////////

private var _table: Map<String, Int>? = null
public val table: Map<String, Int>
    get() {
        if (_table == null) {
            _table = HashMap() // Type parameters are inferred
        }
        return _table ?: throw AssertionError("Set to null by another thread")

    }


/////////////////////////////////////////////////////////////////////////////////////////////////////


//todo :- Resolving overriding conflicts -----


interface A {
    fun foo() { print("A") }
    fun bar()
}

interface B {
    fun foo() { print("B") }
    fun bar() { print("bar") }
}

class C : A {
    override fun bar() { print("bar") }
}

class D : A, B {
    override fun foo() {
        super<A>.foo()
        super<B>.foo()
    }

    override fun bar() {
        super<B>.bar()
    }
}