package com.kotlindemo

import android.graphics.Color
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.ViewGroup
import android.widget.*


class MainActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)



        //  ? null save & value maybe null
        var dep: String?
        dep = "Kotlin"

        val lin_main = findViewById(R.id.ll_main_layout) as LinearLayout

        val showOutput = findViewById(R.id.showOutput) as TextView

        // !! for var have to have value
        showOutput.text = (dep!!)


        var age = 90

        //Convert String to Integer
        age = dep.toInt()


        print("age:" + age)
        print("dep:$dep")

        dep = "Hello"


        /* txt.setOnClickListener {

             Toast.makeText(this, "hello Text", Toast.LENGTH_LONG).show()
         }*/


        //Button Programatically
        var btn_background: Int = 1
        val btnClickMe = findViewById(R.id.btn_kt) as Button

        btnClickMe.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        btnClickMe.setOnClickListener {

            if (btn_background == 2) {
                btnClickMe.setBackgroundColor(Color.BLUE)
                btn_background = 1
            } else if (btn_background == 1) {
                btnClickMe.setBackgroundColor(Color.RED)
                btn_background = 2
            }

        }


    }


   }
