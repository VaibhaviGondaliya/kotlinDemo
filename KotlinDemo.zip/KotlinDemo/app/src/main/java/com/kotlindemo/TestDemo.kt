package com.kotlindemo


fun main(args:Array<String>){

    print("Hii")
    print("Hello,")
    print(3)
}